package com.wiredbraincoffee.reward.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.fail;

public class Test1 {

    @Test
    void myTest() {
        fail("Failing test to see if it runs");
    }
}
