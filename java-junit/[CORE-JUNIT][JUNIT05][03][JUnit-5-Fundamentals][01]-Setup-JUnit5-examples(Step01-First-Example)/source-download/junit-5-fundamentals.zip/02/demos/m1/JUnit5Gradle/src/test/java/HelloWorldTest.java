import org.junit.jupiter.api.Test;

class HelloWorldTest {
    @Test
    void firstTest() {
        System.out.println("First test");
    }
}
