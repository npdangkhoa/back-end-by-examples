To import the projects in Eclipse:
1. File -> Import
2. Existing Maven Project
3. Navigate to the project's directory
4. Select the pom.xml file and click Finish

To import the projects in IntelliJ IDEA
1. In the Welcome to IntelliJ IDEA window, choose the option Open
2. Select the project's directory pom.xml file and click Ok
3. Choose the option Open as a Project

URLs:
Martin Fowler quote
http://bit.ly/mfowlerquote

Structure and Interpretation of Computer Programs quote
http://bit.ly/sicppreface

Pluralsight Course: Introduction to Testing in Java
http://bit.ly/introductiontestingjava

Pluralsight Course: Test-Driven Development Practices in Java
http://bit.ly/tddjavaps

Download IntelliJ IDEA:
https://www.jetbrains.com/idea/download/

Links about the history of JUnit:
https://shebanator.com/2007/08/21/a-brief-history-of-test-frameworks/
http://www.theserverside.com/discussions/thread/39048.html
https://github.com/junit-team/junit5/wiki/Crowdfunding-Campaign
https://www.indiegogo.com/projects/junit-lambda#/

Johannes Link quote
http://bit.ly/interviewjlink

Issues Maven Surefire plugin:
https://github.com/junit-team/junit5/issues/809#issuecomment-330539346
https://github.com/junit-team/junit5-samples/pull/27
