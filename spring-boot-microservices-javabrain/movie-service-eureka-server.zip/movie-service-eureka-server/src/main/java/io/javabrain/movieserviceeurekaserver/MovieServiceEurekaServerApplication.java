package io.javabrain.movieserviceeurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieServiceEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieServiceEurekaServerApplication.class, args);
	}

}
