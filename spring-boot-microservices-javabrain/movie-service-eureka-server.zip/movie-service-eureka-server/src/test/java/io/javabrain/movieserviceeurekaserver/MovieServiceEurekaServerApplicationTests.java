package io.javabrain.movieserviceeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieServiceEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
