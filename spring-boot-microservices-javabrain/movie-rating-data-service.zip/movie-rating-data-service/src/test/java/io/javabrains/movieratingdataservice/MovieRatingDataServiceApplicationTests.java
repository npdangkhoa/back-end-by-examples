package io.javabrains.movieratingdataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRatingDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
